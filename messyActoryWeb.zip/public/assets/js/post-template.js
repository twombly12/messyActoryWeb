            // -------------------------------- ________ Post --------------------------
            // -------------------------------- ________ Post --------------------------
            // -------------------------------- ________ Post --------------------------
            // -------------------------------- ________ Post --------------------------
            // -------------------------------- ________ Post --------------------------
            {
                "postNum": " blogPost_____ ",
                "category": "______",
                "postLink": "/Posts/_____.html",
                "title": ` ______ `,
                "image": `<picture>
<source srcset="../assets/images//_____.webp" type="image/webp">
<source srcset="../assets/images/_____.jpg" type="image/jpg"> 
<img class="main-blog-image" src="../assets/images/_____.webp" alt="_____">
</picture>`,
                "date": `______`,
                "snippet": `<p> ______ </p>`,
                "tableOfContents": `<span class="tableContentsTitle">Table of Contents</span>
    <p> ______ </p>
    <ul>
        <li>
            <a href="#sectionOne"> ______ </a></li>
        <li>
            <a href="#sectionTwo"> ______ </a></li>
        <li>
            <a href="#sectionThree"> ______ </a></li>
        <li>
            <a href="#sectionFour"> ______ </a></li>
        <li>
            <a href="#sectionFive"> ______ </a></li>
        <li>
            <a href="#sectionSix"> ______ </a></li>
        <li>
            <a href="#sectionSeven"> ______ </a></li>
        <li>
            <a href="#sectionEigth"> ______ </a></li>

            <li>
            <a href="#summary">Summary</a></li>
    </ul>`,
                "content": `
    <p> ______ </p>
    <ol>
        <li>
            <h2 id="sectionOne"> ______</h2>
            <p> _____</p>
            <p> _____</p>
        </li>
        <li>
            <h2 id="sectionTwo"> ______</h2>
            <p> _____</p>
            <p> _____</p>
        </li>
        <li>
            <h2 id="sectionThree"> ______</h2>
            <p> _____</p>
            <p> _____</p>
        </li>
        <li>
            <h2 id="sectionFour"> ______</h2>
            <p> _____</p>
            <p> _____</p>
        </li>
        <li>
            <h2 id="sectionFive"> ______</h2>
            <p> _____</p>
            <p> _____</p>
        </li>
        <li>
            <h2 id="sectionSix"> ______</h2>
            <p> _____</p>
            <p> _____</p>
        </li>
        <li>
            <h2 id="sectionSeven"> ______</h2>
            <p> _____</p>
            <p> _____</p>
        </li>
        <li>
            <h2 id="sectionEigth"> ______</h2>
            <p> _____</p>
            <p> _____</p>
        </li>
        <li class="summary-li">
        <h2 id="summary">Summary</h2>
        <p>_____</p>
        </li>
    </ol>
    <h3>_____</h3>
    `
            },