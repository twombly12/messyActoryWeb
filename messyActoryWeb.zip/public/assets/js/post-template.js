{
    "postNum": " postNum ",
    "category": "Agents",
    "postLink": "/public/Posts/link.html",
    "title": ` title `,
    "image": `<picture>
<source srcset="/images/man-image-mime-with-movie-board.webp" type="image/webp">
<source srcset="/images/man-image-mime-with-movie-board.jpg" type="image/jpg"> 
<img class="main-blog-image" src="/images/man-image-mime-with-movie-board.webp" alt="image">
</picture>`,
    "date": `March 4, 2022`,
    "snippet": `<p> blurb </p>`,
    "tableOfContents": `<span class="tableContentsTitle">Table of Contents</span>
    <p> Title </p>
    <ul>
        <li>
            <a href="#sectionOne"> Heading </a></li>
        <li>
            <a href="#sectionTwo"> Heading </a></li>
        <li>
            <a href="#sectionThree"> Heading </a></li>
        <li>
            <a href="#sectionFour"> Heading </a></li>
        <li>
            <a href="#sectionFive"> Heading </a></li>
        <li>
            <a href="#sectionSix"> Heading </a></li>
        <li>
            <a href="#sectionSeven"> Heading </a></li>
        <li>
            <a href="#sectionEigth"> Heading </a></li>

            <li>
            <a href="#summary">Summary</a></li>
    </ul>`,
    "content": `
    <p> Blurb </p>
    <ol>
        <li>
            <h2 id="sectionOne"> One </h2>
            <p> Sentence </p>
            <p> Sentence </p>
        </li>
        <li>
            <h2 id="sectionTwo"> One </h2>
            <p> Sentence </p>
            <p> Sentence </p>
        </li>
        <li>
            <h2 id="sectionThree"> One </h2>
            <p> Sentence </p>
            <p> Sentence </p>
        </li>
        <li>
            <h2 id="sectionFour"> One </h2>
            <p> Sentence </p>
            <p> Sentence </p>
        </li>
        <li>
            <h2 id="sectionFive"> One </h2>
            <p> Sentence </p>
            <p> Sentence </p>
        </li>
        <li>
            <h2 id="sectionSix"> One </h2>
            <p> Sentence </p>
            <p> Sentence </p>
        </li>
        <li>
            <h2 id="sectionSeven"> One </h2>
            <p> Sentence </p>
            <p> Sentence </p>
        </li>
        <li>
            <h2 id="sectionEigth"> One </h2>
            <p> Sentence </p>
            <p> Sentence </p>
        </li>
        <li class="summary-li">
        <h2 id="summary">Summary</h2>
        <p>Babsey says stuff about things here</p>
        </li>
    </ol>
    <h3>I hope you have a wonderful agent who checked all five of these points! </h3>
    `
},